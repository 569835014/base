export default function (url) {
  return () => System.import(`@/${url}`)
}
export const asyncImport = (url) => {
  return () => import(`@/${url}`)
}
// export const asyncRequire=(url,name)=>{
//   return (r)=>  require.ensure([], () => r(require(`@/${url}`)), name)
// }
