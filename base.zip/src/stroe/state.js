
const state = {
  user: null,
  loading:false
}

export default state
