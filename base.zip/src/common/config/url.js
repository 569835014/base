const LOGIN_URL='/admin/login'

export {
  LOGIN_URL
}
