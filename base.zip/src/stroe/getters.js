export const user = (store) => {
  return store.user
}
export const loading = (store) => {
  return store.loading
}
